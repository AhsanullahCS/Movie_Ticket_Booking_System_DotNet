﻿<%@ Page Title="Check Membership" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="CheckMembership.aspx.cs" Inherits="ap_project.CheckMembership" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <h2 class="text-center text-danger mb-4">Check Membership Status</h2>

    <div class="container" style="max-width:500px;">

        <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" placeholder="Enter Email"></asp:TextBox>
        <br />

        <asp:Button ID="btnCheck" runat="server" Text="Check Status" CssClass="btn btn-primary w-100" OnClick="btnCheck_Click" />

        <br /><br />

        <asp:Label ID="lblResult" runat="server" ForeColor="Yellow"></asp:Label>

    </div>

</asp:Content>