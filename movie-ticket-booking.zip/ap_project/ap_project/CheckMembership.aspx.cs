﻿using System;
using System.Data.SqlClient;

namespace ap_project
{
    public partial class CheckMembership : System.Web.UI.Page
    {
        string conn = @"Data Source=DESKTOP-6EE5ANN\MSSQLSERVER01;Initial Catalog=GymDB;Integrated Security=True";

        protected void btnCheck_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conn);
            con.Open();

            SqlCommand cmd = new SqlCommand(
                "SELECT m.Name, p.PlanName, m.StartDate, m.EndDate " +
                "FROM Members m INNER JOIN Plans p ON m.PlanID = p.PlanID " +
                "WHERE m.Email = @Email", con);

            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                string name = dr["Name"].ToString();
                string plan = dr["PlanName"].ToString();
                DateTime start = Convert.ToDateTime(dr["StartDate"]);
                DateTime end = Convert.ToDateTime(dr["EndDate"]);

                string status;

                if (DateTime.Now <= end)
                {
                    status = "ACTIVE ✔";
                }
                else
                {
                    status = "EXPIRED ❌";
                }

                lblResult.Text =
                    "Name: " + name + "<br/>" +
                    "Plan: " + plan + "<br/>" +
                    "Start Date: " + start.ToShortDateString() + "<br/>" +
                    "End Date: " + end.ToShortDateString() + "<br/>" +
                    "Status: " + status;
            }
            else
            {
                lblResult.Text = "No Membership Found ❌";
            }

            con.Close();
        }
    }
}