﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ap_project
{
    public partial class ViewPlans : System.Web.UI.Page
    {
        string conn = @"Data Source=DESKTOP-6EE5ANN\MSSQLSERVER01;Initial Catalog=GymDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) // load only once
            {
                LoadPlans();
            }
        }
        void LoadPlans()
        {
            SqlConnection con = new SqlConnection(conn);

            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Plans", con);

            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}