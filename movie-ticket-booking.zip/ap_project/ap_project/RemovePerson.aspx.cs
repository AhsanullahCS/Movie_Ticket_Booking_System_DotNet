﻿using System;
using System.Data.SqlClient;

namespace ap_project
{
    public partial class RemovePerson : System.Web.UI.Page
    {
        string conn = @"Data Source=DESKTOP-6EE5ANN\MSSQLSERVER01;Initial Catalog=GymDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Admin"] == null)
            {
                Response.Redirect("AdminLogin.aspx");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conn);

            con.Open();

            SqlCommand cmd = new SqlCommand("DELETE FROM Members WHERE Email=@Email", con);

            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);

            int rows = cmd.ExecuteNonQuery();

            con.Close();

            if (rows > 0)
            {
                lblMsg.Text = "Member Deleted Successfully ✔";
            }
            else
            {
                lblMsg.Text = "No Member Found ❌";
            }

            txtEmail.Text = "";
        }
    }
}