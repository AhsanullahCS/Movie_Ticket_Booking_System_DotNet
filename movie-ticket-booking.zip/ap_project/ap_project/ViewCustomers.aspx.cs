﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ap_project
{
    public partial class ViewCustomers : System.Web.UI.Page
    {
        string conn = @"Data Source=DESKTOP-6EE5ANN\MSSQLSERVER01;Initial Catalog=GymDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Admin"] == null) // security check
            {
                Response.Redirect("AdminLogin.aspx");
            }

            if (!IsPostBack)
            {
                LoadMembers();
            }
        }

        void LoadMembers()
        {
            SqlConnection con = new SqlConnection(conn);

            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Members", con);

            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}