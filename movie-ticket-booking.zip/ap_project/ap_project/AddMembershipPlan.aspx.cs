﻿using System;
using System.Data.SqlClient;

namespace ap_project
{
    public partial class AddMembershipPlan : System.Web.UI.Page
    {
        string conn = @"Data Source=DESKTOP-6EE5ANN\MSSQLSERVER01;Initial Catalog=GymDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Admin"] == null)
            {
                Response.Redirect("AdminLogin.aspx");
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conn); // connection created here

            con.Open(); // open connection

            SqlCommand cmd = new SqlCommand(
                "INSERT INTO Plans (PlanName, Price, DurationMonths) VALUES (@Name, @Price, @Duration)", con);

            cmd.Parameters.AddWithValue("@Name", txtPlanName.Text);
            cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
            cmd.Parameters.AddWithValue("@Duration", txtDuration.Text);

            cmd.ExecuteNonQuery();

            con.Close(); // properly closed here

            lblMsg.Text = "Plan Added Successfully ✔";

            txtPlanName.Text = "";
            txtPrice.Text = "";
            txtDuration.Text = "";
        }
    }
}