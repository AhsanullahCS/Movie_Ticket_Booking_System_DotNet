﻿<%@ Page Title="Admin Login" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="AdminLogin.aspx.cs" Inherits="ap_project.AdminLogin" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        .login-box {
            width: 100%;
            max-width: 400px;
            margin: auto;
        }
        .login-title {
            text-align: center;
            font-weight: 700;
            margin-bottom: 25px;
            color: #ff4d4d;
        }
        .form-control {
            margin-bottom: 15px;
        }
        .btn-login {
            width: 100%;
        }
    </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <div class="login-box">

        <h3 class="login-title">Admin Login</h3>

        <asp:Label ID="lblMsg" runat="server" ForeColor="Red"></asp:Label>

        <asp:TextBox ID="txtUser" runat="server" CssClass="form-control" Placeholder="Enter Username"></asp:TextBox>

        <asp:TextBox ID="txtPass" runat="server" CssClass="form-control" Placeholder="Enter Password" TextMode="Password"></asp:TextBox>

        <asp:Button ID="btnLogin" runat="server" Text="Login" CssClass="btn btn-danger btn-login" OnClick="btnLogin_Click" />

    </div>

</asp:Content>