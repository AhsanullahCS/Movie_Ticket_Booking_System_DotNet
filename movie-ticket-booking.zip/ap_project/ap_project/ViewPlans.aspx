﻿<%@ Page Title="View Plans" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="ViewPlans.aspx.cs" Inherits="ap_project.ViewPlans" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <h2 class="text-center text-danger mb-4">Available Membership Plans</h2>

    <div class="container">

        <asp:GridView ID="GridView1" runat="server" 
            CssClass="table table-dark table-striped text-center"
            AutoGenerateColumns="False">

            <Columns>
                <asp:BoundField DataField="PlanID" HeaderText="ID" />
                <asp:BoundField DataField="PlanName" HeaderText="Plan Name" />
                <asp:BoundField DataField="Price" HeaderText="Price (PKR)" />
                <asp:BoundField DataField="DurationMonths" HeaderText="Duration (Months)" />
            </Columns>

        </asp:GridView>

    </div>

</asp:Content>