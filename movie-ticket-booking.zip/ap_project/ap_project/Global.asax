﻿<%@ Application Codebehind="Global.asax.cs" Inherits="ap_project.Global" Language="C#" %>
