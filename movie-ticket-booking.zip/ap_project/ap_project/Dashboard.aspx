﻿<%@ Page Title="Admin Dashboard" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="Dashboard.aspx.cs" Inherits="ap_project.Dashboard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">

    <style>
        .dashboard-title {
            text-align: center;
            font-weight: 800;
            color: #ff4d4d;
            margin-bottom: 30px;
        }

        .card-box {
            background: rgba(255,255,255,0.1);
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            transition: 0.3s;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
        }

        .card-box:hover {
            transform: scale(1.05);
        }

        .btn-admin {
            width: 100%;
            margin-top: 10px;
        }
    </style>

</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <h2 class="dashboard-title">Admin Dashboard</h2>

    <div class="row justify-content-center">

        <div class="col-md-3">
            <div class="card-box">
                <h5>Add Membership Plan</h5>
                <asp:Button ID="btnAddPlan" runat="server" Text="Go" CssClass="btn btn-success btn-admin" PostBackUrl="AddMembershipPlan.aspx" />
            </div>
        </div>

        <div class="col-md-3">
            <div class="card-box">
                <h5>Remove Member</h5>
                <asp:Button ID="btnRemove" runat="server" Text="Go" CssClass="btn btn-danger btn-admin" PostBackUrl="RemovePerson.aspx" />
            </div>
        </div>

        <div class="col-md-3">
            <div class="card-box">
                <h5>View Customers</h5>
                <asp:Button ID="btnView" runat="server" Text="Go" CssClass="btn btn-primary btn-admin" PostBackUrl="ViewCustomers.aspx" />
            </div>
        </div>

    </div>

</asp:Content>