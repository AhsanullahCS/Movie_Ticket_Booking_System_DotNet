﻿<%@ Page Title="Buy Membership" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="BuyMembership.aspx.cs" Inherits="ap_project.BuyMembership" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <h2 class="text-center text-danger mb-4">Buy Membership</h2>

    <div class="container" style="max-width:500px;">

        <asp:Label ID="lblMsg" runat="server" ForeColor="Yellow"></asp:Label>

        <div class="mb-3">
            <asp:TextBox ID="txtName" runat="server" CssClass="form-control" placeholder="Your Name"></asp:TextBox>
        </div>

        <div class="mb-3">
            <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" placeholder="Email"></asp:TextBox>
        </div>

        <div class="mb-3">
            <asp:TextBox ID="txtPhone" runat="server" CssClass="form-control" placeholder="Phone"></asp:TextBox>
        </div>

        <div class="mb-3">
            <asp:DropDownList ID="ddlPlans" runat="server" CssClass="form-control"></asp:DropDownList>
        </div>

        <asp:Button ID="btnBuy" runat="server" Text="Buy Membership" CssClass="btn btn-success w-100" OnClick="btnBuy_Click" />

    </div>

</asp:Content>