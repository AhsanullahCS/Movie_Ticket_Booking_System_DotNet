﻿<%@ Page Title="Remove Member" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="RemovePerson.aspx.cs" Inherits="ap_project.RemovePerson" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <h2 class="text-center text-danger mb-4">Remove Member</h2>

    <div class="container" style="max-width:500px;">

        <asp:Label ID="lblMsg" runat="server" ForeColor="Red"></asp:Label>

        <div class="mb-3">
            <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" placeholder="Enter Member Email"></asp:TextBox>
        </div>

        <asp:Button ID="btnDelete" runat="server" Text="Delete Member" CssClass="btn btn-danger w-100" OnClick="btnDelete_Click" />

    </div>

</asp:Content>