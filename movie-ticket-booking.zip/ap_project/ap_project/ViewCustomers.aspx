﻿<%@ Page Title="View Customers" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="ViewCustomers.aspx.cs" Inherits="ap_project.ViewCustomers" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <h2 class="text-center text-danger mb-4">Registered Members</h2>

    <div class="container">

        <asp:GridView ID="GridView1" runat="server"
            CssClass="table table-dark table-striped text-center"
            AutoGenerateColumns="False">

            <Columns>
                <asp:BoundField DataField="MemberID" HeaderText="ID" />
                <asp:BoundField DataField="Name" HeaderText="Name" />
                <asp:BoundField DataField="Email" HeaderText="Email" />
                <asp:BoundField DataField="Phone" HeaderText="Phone" />
                <asp:BoundField DataField="PlanID" HeaderText="Plan ID" />
                <asp:BoundField DataField="StartDate" HeaderText="Start Date" />
                <asp:BoundField DataField="EndDate" HeaderText="End Date" />
            </Columns>

        </asp:GridView>

    </div>

</asp:Content>