﻿using System;

namespace ap_project
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string adminUser = "admin"; 
            string adminPass = "123"; 

            if (txtUser.Text == adminUser && txtPass.Text == adminPass) 
            {
                Session["Admin"] = "true"; 
                Response.Redirect("Dashboard.aspx"); 
            }
            else
            {
                lblMsg.Text = "Invalid Username or Password"; 
            }
        }
    }
}