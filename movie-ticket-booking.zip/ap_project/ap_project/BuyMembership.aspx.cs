﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ap_project
{
    public partial class BuyMembership : System.Web.UI.Page
    {
        string conn = @"Data Source=DESKTOP-6EE5ANN\MSSQLSERVER01;Initial Catalog=GymDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadPlans();
            }
        }

        void LoadPlans()
        {
            SqlConnection con = new SqlConnection(conn);

            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Plans", con);

            DataTable dt = new DataTable();
            da.Fill(dt);

            ddlPlans.DataSource = dt;
            ddlPlans.DataTextField = "PlanName";
            ddlPlans.DataValueField = "PlanID";
            ddlPlans.DataBind();

            ddlPlans.Items.Insert(0, "-- Select Plan --");
        }

        protected void btnBuy_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conn);

            con.Open();

            // Get plan duration
            SqlCommand cmdPlan = new SqlCommand("SELECT DurationMonths FROM Plans WHERE PlanID=@id", con);
            cmdPlan.Parameters.AddWithValue("@id", ddlPlans.SelectedValue);

            int duration = Convert.ToInt32(cmdPlan.ExecuteScalar());

            DateTime startDate = DateTime.Now;
            DateTime endDate = startDate.AddMonths(duration);

            // Insert member
            SqlCommand cmd = new SqlCommand(
                "INSERT INTO Members (Name, Email, Phone, PlanID, StartDate, EndDate) VALUES (@n,@e,@p,@pid,@s,@en)", con);

            cmd.Parameters.AddWithValue("@n", txtName.Text);
            cmd.Parameters.AddWithValue("@e", txtEmail.Text);
            cmd.Parameters.AddWithValue("@p", txtPhone.Text);
            cmd.Parameters.AddWithValue("@pid", ddlPlans.SelectedValue);
            cmd.Parameters.AddWithValue("@s", startDate);
            cmd.Parameters.AddWithValue("@en", endDate);

            cmd.ExecuteNonQuery();

            con.Close();

            lblMsg.Text = "Membership Purchased Successfully ✔";
        }
    }
}