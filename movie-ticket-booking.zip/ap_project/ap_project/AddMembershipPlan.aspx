﻿<%@ Page Title="Add Plan" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="AddMembershipPlan.aspx.cs" Inherits="ap_project.AddMembershipPlan" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <h2 class="text-center text-danger mb-4">Add Membership Plan</h2>

    <div class="container" style="max-width:500px;">

        <asp:Label ID="lblMsg" runat="server" ForeColor="Red"></asp:Label>

        <div class="mb-3">
            <asp:TextBox ID="txtPlanName" runat="server" CssClass="form-control" placeholder="Plan Name"></asp:TextBox>
        </div>

        <div class="mb-3">
            <asp:TextBox ID="txtPrice" runat="server" CssClass="form-control" placeholder="Price"></asp:TextBox>
        </div>

        <div class="mb-3">
            <asp:TextBox ID="txtDuration" runat="server" CssClass="form-control" placeholder="Duration (Months)"></asp:TextBox>
        </div>

        <asp:Button ID="btnAdd" runat="server" Text="Add Plan" CssClass="btn btn-success w-100" OnClick="btnAdd_Click" />

    </div>

</asp:Content>