﻿<%@ Page Title="Home" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="Home.aspx.cs" Inherits="ap_project.Home" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        .motto-h1 { 
            font-size: 4rem; 
            font-weight: 900; 
            color: #ff4d4d; 
            text-transform: uppercase; 
            letter-spacing: 3px;
            margin-bottom: 0;
        }
        .motto-p { 
            font-size: 1.6rem; 
            color: #ffffff; 
            font-style: italic; 
            margin-top: 10px;
            font-weight: 300;
        }
        .start-btn {
            margin-top: 40px;
            padding: 12px 40px;
            font-weight: bold;
            letter-spacing: 1px;
        }
    </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div>
        <h1 class="motto-h1">PUSH YOUR LIMITS</h1>
        <p class="motto-p">"The only bad workout is the one that didn't happen."</p>
        
        <div class="divider mx-auto" style="width:100px; height:4px; background:#ff4d4d; margin:25px 0;"></div>
        
        <p class="lead">Welcome to the Gorilla Gym Management System.<br /> Your fitness journey starts with one click.</p>
        
        <a href="ViewPlans.aspx" class="btn btn-danger btn-lg rounded-pill start-btn">GET STARTED</a>
    </div>
</asp:Content>